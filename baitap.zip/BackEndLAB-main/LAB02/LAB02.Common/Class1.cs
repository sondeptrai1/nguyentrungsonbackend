﻿using System;
using System.Text;

namespace LAB02.Common
{
    public static class GlobalConfig
    {
        public static void SetupConsole()
        {
            Console.OutputEncoding = Encoding.UTF8;
        }
    }
}
